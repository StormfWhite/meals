"""The week's grocery checklist: what the planned recipes actually need,
merged with what's been checked off / bought / sorted into a section.

Quantities are aggregated once per *cook event*, not once per slot -- a
leftover_group represents one batch spanning several meals, so its
ingredients are only counted once (from whichever linked slot is seen
first) or the grocery list would ask for several times the eggplant a
recipe actually needs.
"""
from __future__ import annotations

import datetime
import re
import uuid
from typing import Optional

from . import aisles, board, ingredients, learning, nutrition, places, prices, recipes, store
from .paths import GROCERIES_FILE


def _load() -> dict:
    return store.load(GROCERIES_FILE, {"weeks": {}})


def _save(data: dict) -> None:
    store.save(GROCERIES_FILE, data)


def week_ingredient_needs(week_start_iso: str) -> dict[str, float]:
    """ingredient_id -> grams needed, counting each leftover_group once."""
    week = board.get_week(week_start_iso)
    ing_by_id = ingredients.by_id()
    seen_groups: set[str] = set()
    needs: dict[str, float] = {}

    for slot in week["slots"].values():
        gid = slot.get("leftover_group")
        if gid:
            if gid in seen_groups:
                continue
            seen_groups.add(gid)
        recipe = recipes.get(slot["recipe_id"])
        if recipe is None:
            continue
        ing_list = slot.get("ingredient_overrides") or recipe["ingredients"]
        for item in ing_list:
            ing = ing_by_id.get(item["ingredient_id"])
            if ing is None:
                continue
            # a unit with no known weight ("1 bunch") is still something to buy:
            # it stays on the list, just without an amount
            grams = nutrition.qty_to_grams(ing, item["qty"], item["unit"]) or 0.0
            needs[item["ingredient_id"]] = needs.get(item["ingredient_id"], 0.0) + grams
    return needs


def active_shop(kind: str = "grocery") -> Optional[dict]:
    """The store (or market) prices are quoted against: whichever one the
    active place has picked."""
    place = places.active()
    if not place:
        return None
    return place.get("market" if kind == "market" else "store")


def get_week_groceries(week_start_iso: str, with_prices: bool = True,
                       allow_network: bool = False) -> list[dict]:
    """Recipe-derived needs (seeded by the learning loop) merged with
    hand-added `extra_items` -- extras are added on top raw, after seeding,
    since they're an explicit "I want this much" rather than a recipe
    quantity the learning loop should be nudging.

    Every item carries the list it belongs on (`shop_list`), which is what
    splits the panel into groceries and farmer's market. Nothing decides
    that here: aisles.py owns the rule and the ingredient owns the answer,
    so an item moved by hand stays moved.

    `allow_network` is off by default deliberately -- a list redraw must
    never turn into forty Kroger requests. Live prices are fetched by an
    explicit refresh (see server.py) and remembered afterwards.
    """
    needs = week_ingredient_needs(week_start_iso)
    ing_by_id = ingredients.by_id()
    week_data = _load()["weeks"].get(week_start_iso, {})
    saved = week_data.get("items", {})
    extra = week_data.get("extra_items", {})

    extra_ids = set(extra)
    grams_by_id = {ing_id: learning.seeded_quantity(ing_id, grams) for ing_id, grams in needs.items()}
    for ing_id, ex in extra.items():
        grams_by_id[ing_id] = grams_by_id.get(ing_id, 0.0) + ex.get("qty_g", 0.0)

    shops = {"grocery": active_shop("grocery"), "market": active_shop("market")}
    out = []
    for ing_id, grams in grams_by_id.items():
        ing = ing_by_id.get(ing_id)
        if ing is None:
            continue
        s = saved.get(ing_id, {})
        # Swiped off: stays off until the plan needs MORE of it than it did then.
        if s.get("removed_g") is not None and grams <= s["removed_g"] + 0.5:
            continue
        shop_list = aisles.list_for(ing)
        typed = extra.get(ing_id, {}).get("qty_text", "")
        label = ingredients.humanize_grams(ing, grams) if grams else ""
        item = {
            "ingredient_id": ing_id,
            "name": ing["name"],
            "planned_qty_g": round(grams, 1),
            "bought_qty_g": s.get("bought_qty_g"),
            # a name added with no amount has no amount -- never a made-up "0 g";
            # a typed amount shows as typed, beside whatever the meals need
            "unit_label": " + ".join(t for t in (label, typed) if t),
            "section": s.get("section", ing.get("store_section")),
            "checked": s.get("checked", False),
            "source": "extra" if ing_id in extra_ids else "recipe",
            "shop_list": shop_list,
            "category": ing.get("category", "other"),
            "fdc_matched": bool(ing.get("fdc_id")),
        }
        if with_prices:
            item.update(_priced(ing, item, shops[shop_list], allow_network))
        out.append(item)
    out.sort(key=lambda r: r["name"].lower())
    return out


def _priced(ingredient: dict, item: dict, shop: Optional[dict], allow_network: bool) -> dict:
    """Price fields for one row: what one costs, how many you need, and
    what that comes to. Missing stays missing -- an item with no price
    contributes nothing to the total and is counted as unpriced instead,
    because a total that quietly skips items reads as complete."""
    price = prices.price_for(ingredient, shop, allow_network=allow_network)
    if not price:
        return {"price": None, "packages": None, "est_cost": None,
                "price_source": None, "price_age_days": None, "price_label": ""}
    packages = prices.packages_needed(item["planned_qty_g"], price.get("package_g"))
    return {
        "price": price["price"],
        "packages": packages,
        "est_cost": round(price["price"] * packages, 2),
        "price_source": price.get("source"),
        "price_age_days": price.get("age_days"),
        "price_label": price.get("label", ""),
        "aisle": price.get("aisle", ""),
    }


def list_totals(items: list[dict]) -> dict:
    """Per-list estimated cost, with the honesty counter beside it."""
    out = {}
    for shop_list in (aisles.GROCERY, aisles.MARKET):
        rows = [i for i in items if i.get("shop_list") == shop_list and not i.get("checked")]
        priced = [i for i in rows if i.get("est_cost") is not None]
        out[shop_list] = {
            "items": len(rows),
            "estimated": round(sum(i["est_cost"] for i in priced), 2) if priced else None,
            "unpriced": len(rows) - len(priced),
        }
    return out


def add_extra_item(week_start_iso: str, ingredient_id: str, qty_g: Optional[float] = None,
                   qty_text: Optional[str] = None) -> list[dict]:
    """A catalog item added straight to the grocery list, not derived from
    any planned recipe -- repeated adds accumulate rather than overwrite.
    The amount is optional and is whatever was typed ("2 lb", "a dozen"):
    kept as text, never turned into grams, so a bare name is a whole entry
    and "2 lb" reads back as "2 lb". `qty_g` stays for callers that do
    have a weight."""
    data = _load()
    week = data["weeks"].setdefault(week_start_iso, {"items": {}, "extra_items": {}, "free_list": []})
    extras = week.setdefault("extra_items", {})
    entry = extras.setdefault(ingredient_id, {"qty_g": 0.0})
    entry["qty_g"] = entry.get("qty_g", 0.0) + (qty_g or 0.0)
    if qty_text and qty_text.strip():
        entry["qty_text"] = " + ".join(t for t in (entry.get("qty_text"), qty_text.strip()) if t)
    week.setdefault("items", {}).get(ingredient_id, {}).pop("removed_g", None)
    _save(data)
    return get_week_groceries(week_start_iso)


def remove_item(week_start_iso: str, ingredient_id: str) -> list[dict]:
    """Take a row off this week's list whatever put it there (the swipe):
    a hand-add is dropped, and a recipe need is hidden at today's amount --
    planning more of it later brings it back, since that's a new need."""
    needs = week_ingredient_needs(week_start_iso)
    need = learning.seeded_quantity(ingredient_id, needs[ingredient_id]) if ingredient_id in needs else 0.0
    data = _load()
    week = data["weeks"].setdefault(week_start_iso, {"items": {}, "extra_items": {}, "free_list": []})
    week.setdefault("extra_items", {}).pop(ingredient_id, None)
    if need:
        week.setdefault("items", {}).setdefault(ingredient_id, {})["removed_g"] = round(need, 1)
    _save(data)
    return get_week_groceries(week_start_iso)


# ── the usuals ───────────────────────────────────────────────────────────
#
# What gets put on the list by hand week after week (eggs, milk, "basil")
# comes back as a suggestion: tap it and it's real, ✕ it and it's gone for
# that week -- and the ✕ counts against it, so something stopped being
# bought fades out instead of nagging. Recipe needs aren't learned here:
# the plan already puts those on the list.

SUGGEST_LOOKBACK = 8        # weeks of history considered
SUGGEST_DECAY = 0.8         # last week counts 0.8, the week before 0.64, ...
SUGGEST_MIN_WEEKS = 2       # once is a one-off, not a usual
SUGGEST_MIN_SCORE = 0.9     # twice in the last ~3 weeks clears it; twice two months ago doesn't
DISMISS_WEIGHT = 0.5

_LEADING_QTY = re.compile(r"^\s*(?:\d+(?:[./]\d+)?|a few|a couple(?: of)?|some|few)\s*(?:x\b)?\s*", re.I)


def _line_name(text: str) -> str:
    """ "3 eggplant" and "2 eggplant" are the same usual: what's bought, not how many."""
    return _LEADING_QTY.sub("", text).strip()


def _weeks_between(a_iso: str, b_iso: str) -> int:
    return max(1, round((datetime.date.fromisoformat(b_iso) - datetime.date.fromisoformat(a_iso)).days / 7))


def suggestions(week_start_iso: str) -> list[dict]:
    weeks = _load()["weeks"]
    past = sorted(w for w in weeks if w < week_start_iso)[-SUGGEST_LOOKBACK:]
    ing_by_id = ingredients.by_id()
    stats: dict[str, dict] = {}

    def tally(key: str, age: int, sign: float, **fields) -> None:
        st = stats.setdefault(key, {"score": 0.0, "got": 0, **fields})
        st["score"] += sign * SUGGEST_DECAY ** age
        if sign > 0:
            st["got"] += 1
            st.update(fields)   # weeks run oldest-first, so the newest wording wins

    for w in past:
        wk, age = weeks[w], _weeks_between(w, week_start_iso)
        got = set()
        for ing_id in wk.get("extra_items", {}):
            if ing_id in ing_by_id and wk.get("items", {}).get(ing_id, {}).get("removed_g") is None:
                got.add("i:" + ing_id)
                tally("i:" + ing_id, age, 1, ingredient_id=ing_id)
        for line in wk.get("free_list", []):
            name = _line_name(line["text"])
            key = "t:" + name.lower()
            if name and key not in got:
                got.add(key)
                tally(key, age, 1, text=name)
        for key in wk.get("dismissed", []):
            if key not in got:
                tally(key, age, -DISMISS_WEIGHT)

    this_week = weeks.get(week_start_iso, {})
    current = get_week_groceries(week_start_iso, with_prices=False)
    on_list = {"i:" + i["ingredient_id"] for i in current} | {"t:" + i["name"].lower() for i in current}
    on_list |= {"t:" + _line_name(l["text"]).lower() for l in this_week.get("free_list", [])}
    on_list |= set(this_week.get("dismissed", []))

    out = []
    for key, st in stats.items():
        if key in on_list or st["got"] < SUGGEST_MIN_WEEKS or st["score"] < SUGGEST_MIN_SCORE:
            continue
        if key.startswith("i:"):
            ing = ing_by_id[st["ingredient_id"]]
            name, shop_list = ing["name"], aisles.list_for(ing)
        else:
            name, shop_list = st["text"], aisles.MARKET   # lines live on the market list
        out.append({"key": key, "name": name, "shop_list": shop_list,
                    "weeks": st["got"], "of": len(past), "score": round(st["score"], 3)})
    out.sort(key=lambda s: (-s["score"], s["name"].lower()))
    return out


def accept_suggestion(week_start_iso: str, key: str) -> None:
    if key.startswith("i:"):
        add_extra_item(week_start_iso, key[2:])
    elif key.startswith("t:"):
        hit = next((s for s in suggestions(week_start_iso) if s["key"] == key), None)
        add_free_item(week_start_iso, hit["name"] if hit else key[2:])
    else:
        raise KeyError(key)


def dismiss_suggestion(week_start_iso: str, key: str) -> None:
    data = _load()
    week = data["weeks"].setdefault(week_start_iso, {"items": {}, "extra_items": {}, "free_list": []})
    dismissed = week.setdefault("dismissed", [])
    if key not in dismissed:
        dismissed.append(key)
    _save(data)


def remove_extra_item(week_start_iso: str, ingredient_id: str) -> list[dict]:
    data = _load()
    week = data["weeks"].get(week_start_iso, {})
    week.get("extra_items", {}).pop(ingredient_id, None)
    _save(data)
    return get_week_groceries(week_start_iso)


# ── free list ────────────────────────────────────────────────────────────
#
# A completely separate, unstructured list ("3 eggplant", "two tomatoes")
# for a farmer's-market-style trip that doesn't map to recipe ingredients.
# Deliberately no quantity/word parsing -- it's stored and exported exactly
# as typed, trading structure for zero friction.

def list_free_items(week_start_iso: str) -> list[dict]:
    return _load()["weeks"].get(week_start_iso, {}).get("free_list", [])


def add_free_item(week_start_iso: str, text: str) -> list[dict]:
    data = _load()
    week = data["weeks"].setdefault(week_start_iso, {"items": {}, "extra_items": {}, "free_list": []})
    week.setdefault("free_list", []).append({
        "id": "f_" + uuid.uuid4().hex[:8], "text": text.strip(), "checked": False,
    })
    _save(data)
    return week["free_list"]


def update_free_item(week_start_iso: str, item_id: str, fields: dict) -> list[dict]:
    data = _load()
    week = data["weeks"].get(week_start_iso, {"items": {}, "extra_items": {}, "free_list": []})
    item = next((i for i in week.get("free_list", []) if i["id"] == item_id), None)
    if item is None:
        raise KeyError(item_id)
    for key in ("text", "checked"):
        if key in fields and fields[key] is not None:
            item[key] = fields[key].strip() if key == "text" else fields[key]
    _save(data)
    return week["free_list"]


def delete_free_item(week_start_iso: str, item_id: str) -> list[dict]:
    data = _load()
    week = data["weeks"].get(week_start_iso, {})
    before = len(week.get("free_list", []))
    week["free_list"] = [i for i in week.get("free_list", []) if i["id"] != item_id]
    _save(data)
    if len(week["free_list"]) == before:
        raise KeyError(item_id)
    return week["free_list"]


def free_list_export_text(week_start_iso: str) -> str:
    items = list_free_items(week_start_iso)
    if not items:
        return "(nothing on the free list)"
    return "\n".join(f"- {i['text']}" for i in items)


def update_item(week_start_iso: str, ingredient_id: str, fields: dict) -> dict:
    """`fields` holds only the keys the caller actually sent (see server.py's
    `exclude_unset`) -- unlike a plain None-means-skip signature, this lets
    a bought quantity be explicitly cleared back to "not yet bought"."""
    data = _load()
    week = data["weeks"].setdefault(week_start_iso, {"items": {}})
    item = week["items"].setdefault(ingredient_id, {})
    for key in ("bought_qty_g", "section", "checked"):
        if key in fields:
            item[key] = fields[key]
    _save(data)
    matches = [i for i in get_week_groceries(week_start_iso) if i["ingredient_id"] == ingredient_id]
    return matches[0] if matches else {}


def set_section(week_start_iso: str, ingredient_id: str, section: Optional[str]) -> dict:
    """Unconditional, unlike update_item's partial-update semantics -- this
    is the dedicated section-move endpoint, so `None` means "back to
    Unsorted", not "leave it alone"."""
    data = _load()
    week = data["weeks"].setdefault(week_start_iso, {"items": {}})
    item = week["items"].setdefault(ingredient_id, {})
    item["section"] = section
    _save(data)
    matches = [i for i in get_week_groceries(week_start_iso) if i["ingredient_id"] == ingredient_id]
    return matches[0] if matches else {}


def get_allocation(week_start_iso: str) -> list[dict]:
    out = []
    for item in get_week_groceries(week_start_iso):
        bought = item["bought_qty_g"]
        planned = item["planned_qty_g"]
        if bought is None:
            out.append({**item, "claimed_qty_g": None, "unclaimed_qty_g": None, "overcommitted_g": None})
            continue
        out.append({
            **item,
            "claimed_qty_g": round(min(bought, planned), 1),
            "unclaimed_qty_g": round(max(0.0, bought - planned), 1),
            "overcommitted_g": round(max(0.0, planned - bought), 1),
        })
    return out


def export_text(week_start_iso: str, section: str) -> str:
    items = [i for i in get_week_groceries(week_start_iso) if i["section"] == section]
    if not items:
        return "(nothing needed)"
    return "\n".join(f"- {i['unit_label']} {i['name']}" for i in items)
